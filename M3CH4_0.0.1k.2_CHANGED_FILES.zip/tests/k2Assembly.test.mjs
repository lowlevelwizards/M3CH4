import test from 'node:test';
import assert from 'node:assert/strict';
import { makeTestAssembly, inspectAssembly, installedPart, setGeneratorMount, generatorMount, BY_ID, graphWorldPoses, equip, remove, partsFor } from '../components.js';
import { graphFromStations, validateGraph } from '../assemblyGraph.js';
import { MACHINE_SAVE_KEY, MACHINE_SAVE_VERSION, encodeMachine, decodeMachine } from '../persistence.js';
import { createTargetCondition } from '../combat.js';
import { createFunctionalDamage } from '../functionalDamage.js';
function state(assembly = makeTestAssembly()) {
    return { assembly, damage: createFunctionalDamage(), playerCondition: createTargetCondition(assembly, true) };
}
test('existing starter still has the same mass and socket positions', () => {
    const a = makeTestAssembly(), check = inspectAssembly(a);
    assert.equal(check.ready, true);
    assert.equal(check.massKg, 4090);
    const pose = graphWorldPoses(a.graph, BY_ID, installedPart(a, 'structure').definition.center).get(installedPart(a, 'power').instance.serial);
    assert.deepEqual(pose.position, [0, 2.01, .86]);
});
test('offset generator is visible to the structural graph, load-rated and 85 kg heavier', () => {
    const a = makeTestAssembly(), serial = installedPart(a, 'power').instance.serial;
    const fit = setGeneratorMount(a, 'offset');
    assert.equal(fit.ok, true, fit.reason);
    assert.equal(generatorMount(a), 'offset');
    assert.equal(a.graph.nodes[serial].parentSerial, 'BK-' + serial);
    const check = inspectAssembly(a);
    assert.equal(check.ready, true, check.graphCheck.errors.join('; '));
    assert.equal(check.massKg, 4175);
    assert.equal(check.adapters.filter(p => p.id === 'bracket-generator-offset').length, 1);
    const pose = graphWorldPoses(a.graph, BY_ID, installedPart(a, 'structure').definition.center).get(serial);
    assert.deepEqual(pose.position.map(x => Math.round(x * 100)), [-116, 215, 81]);
});
test('restoring the factory mount keeps unique identity and damage', () => {
    const a = makeTestAssembly(), power = installedPart(a, 'power').instance;
    power.condition = .4; power.wear = .19; power.repairs = 3;
    assert.equal(setGeneratorMount(a, 'offset').ok, true);
    assert.equal(setGeneratorMount(a, 'standard').ok, true);
    assert.equal(generatorMount(a), 'standard');
    assert.equal(inspectAssembly(a).massKg, 4090);
    assert.equal(installedPart(a, 'power').instance, power);
    assert.deepEqual([power.condition, power.wear, power.repairs], [.4, .19, 3]);
});
test('invalid mount edits and parent removal leave attached equipment intact', () => {
    const a = makeTestAssembly(), original = JSON.stringify(a.graph);
    assert.equal(setGeneratorMount(a, 'unknown').ok, false);
    assert.equal(JSON.stringify(a.graph), original);
    assert.equal(setGeneratorMount(a, 'offset').ok, true);
    const mounted = JSON.stringify(a.graph);
    assert.equal(remove(a, 'structure').ok, false);
    assert.equal(JSON.stringify(a.graph), mounted);
    assert.throws(() => equip(a, 'power', 'power-air'), /Custom mounts/);
    assert.equal(inspectAssembly(a).ready, true);
});
test('both existing hip hardware and generator bracket count their real masses once', () => {
    const a = makeTestAssembly();
    equip(a, 'mobility', 'legs-hauler');
    assert.equal(setGeneratorMount(a, 'offset').ok, true);
    const check = inspectAssembly(a);
    assert.equal(check.massKg, 4090 + (1520 - 1240) + 110 + 85);
    assert.equal(check.ready, true, check.checks.map(c => c.reason).join('; '));
});
test('v3 roundtrip saves nested socket, serial, drive faults, wear and armor', () => {
    const a = makeTestAssembly(), power = installedPart(a, 'power').instance;
    power.condition = .71; power.wear = .12; power.repairs = 2;
    assert.equal(setGeneratorMount(a, 'offset').ok, true);
    const s = state(a);
    s.damage.drives[installedPart(a, 'mobility').instance.serial] = { left: .42, right: .9 };
    s.playerCondition.parts.power.integrity = 31;
    s.playerCondition.parts.power.armor = 6;
    s.playerCondition.parts.power.impacts = 5;
    s.playerCondition.shotsHit = 9;
    assert.equal(MACHINE_SAVE_KEY, 'mech-arena-machine-v1');
    const raw = JSON.parse(encodeMachine(s));
    assert.equal(raw.version, MACHINE_SAVE_VERSION);
    const loaded = decodeMachine(JSON.stringify(raw));
    assert.equal(loaded.status, 'restored');
    assert.equal(generatorMount(loaded.assembly), 'offset');
    const p = loaded.assembly.owned.find(item => item.serial === power.serial);
    assert.deepEqual([p.condition, p.wear, p.repairs], [.71, .12, 2]);
    assert.deepEqual(loaded.damage.drives, s.damage.drives);
    assert.deepEqual([loaded.playerCondition.parts.power.integrity, loaded.playerCondition.parts.power.armor, loaded.playerCondition.parts.power.impacts], [31, 6, 5]);
    assert.equal(loaded.playerCondition.shotsHit, 9);
});
test('both previous save formats migrate without discarding machine history', () => {
    const s = state();
    s.assembly.owned[0].repairs = 3;
    s.assembly.owned[0].condition = .8;
    s.damage.drives[installedPart(s.assembly, 'mobility').instance.serial] = { left: .6, right: .4 };
    s.playerCondition.parts.structure.integrity = 91;
    for (const version of [1, 2]) {
        const raw = JSON.parse(encodeMachine(s));
        raw.version = version;
        if (version === 1) delete raw.assembly.graph;
        const loaded = decodeMachine(JSON.stringify(raw));
        assert.equal(loaded.status, 'migrated');
        assert.equal(loaded.assembly.owned[0].repairs, 3);
        assert.equal(loaded.assembly.owned[0].condition, .8);
        assert.deepEqual(loaded.damage.drives, s.damage.drives);
        assert.equal(loaded.playerCondition.parts.structure.integrity, 91);
    }
});
test('an incomplete save can reload as a non-deployable garage machine', () => {
    const s = state(), a = s.assembly;
    delete a.installed.structure;
    a.graph = graphFromStations(a, BY_ID);
    const loaded = decodeMachine(encodeMachine(s));
    assert.equal(loaded.status, 'restored');
    assert.equal(loaded.assembly.installed.structure, undefined);
    assert.equal(inspectAssembly(loaded.assembly).ready, false);
});
test('a forged bracket is rejected without silently regenerating the graph', () => {
    const s = state();
    assert.equal(setGeneratorMount(s.assembly, 'offset').ok, true);
    const p = installedPart(s.assembly, 'power');
    const tampered = JSON.parse(encodeMachine(s));
    tampered.assembly.graph.nodes['BK-' + p.instance.serial].parentSocket = 'combat';
    assert.equal(validateGraph(tampered.assembly.graph, s.assembly, BY_ID).valid, false);
    assert.equal(decodeMachine(JSON.stringify(tampered)).status, 'invalid');
});
test('all 162 existing kit combinations remain structurally representable and persistent', () => {
    let count = 0;
    for (const f of partsFor('structure')) for (const l of partsFor('mobility')) for (const p of partsFor('power')) for (const c of partsFor('command')) for (const w of partsFor('combat')) {
        const a = makeTestAssembly();
        for (const [slot, id] of [['structure', f.id], ['mobility', l.id], ['power', p.id], ['command', c.id], ['combat', w.id]]) equip(a, slot, id);
        const check = inspectAssembly(a), loaded = decodeMachine(encodeMachine(state(a)));
        assert.equal(validateGraph(a.graph, a, BY_ID).valid, true);
        assert.equal(loaded.status, 'restored', f.id + '/' + l.id + '/' + p.id + '/' + c.id + '/' + w.id);
        assert.equal(inspectAssembly(loaded.assembly).massKg, check.massKg);
        count++;
    }
    assert.equal(count, 162);
});
